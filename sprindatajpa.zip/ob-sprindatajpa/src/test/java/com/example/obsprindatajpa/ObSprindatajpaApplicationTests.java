package com.example.obsprindatajpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ObSprindatajpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
